import '../pagecontent.css';
import Navbar from '../../components/js/Navbar';
import bg from '../../images/bg.jpg';

const Explore = () => {
    return(
        <div className="explore-page">
            <div className='page-content'>
                <h1>Explore</h1>
            </div>
        </div>
    )
}

export default Explore;