// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth, signInWithPopup, GoogleAuthProvider, onAuthStateChanged } from "firebase/auth";

// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyAQ470-01c2LildDmzqyftnHTxn4Ufoch8",
  authDomain: "astrome-5aac0.firebaseapp.com",
  projectId: "astrome-5aac0",
  storageBucket: "astrome-5aac0.appspot.com",
  messagingSenderId: "941505859071",
  appId: "1:941505859071:web:904430c4f039676c75ebca",
  measurementId: "G-89QQH5TQ6Y"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const provider = new GoogleAuthProvider();
const auth = getAuth();
const db = getFirestore(app);


export { firebaseConfig, auth, provider, db };
