import '../css/loader.css';

const Loader = () => {
    return(
        <div className='loader-page'>
            <div className='loader-box'>
                <div className='spinner'>
                    
                </div>
            </div>
        </div>
    )
}

export default Loader;