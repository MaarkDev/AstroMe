import '../css/tabloader.css'

const TabLoader = () => {
    return(
        <div className='tab-loader-outer'>
            <div className='tab-loader-box'>
                <div className='tab-loader-spinner'>

                </div>
            </div>
        </div>
    )
}

export default TabLoader;