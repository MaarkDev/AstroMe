import { Navigate } from "react-router-dom"

const Redirects = () => {
    return <Navigate to='/home' replace />
}

export default Redirects;