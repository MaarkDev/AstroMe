import { createContext } from "react";

const DbUserContext = createContext();

export default DbUserContext;