import '../css/profilewidget.css'

const ProfileWidget = () => {
    return(
        <div className='profile-widget-outer'>
            
        </div>
    )
}

export default ProfileWidget;